create definer = test@`` trigger update_theme_summary
    after insert
    on message
    for each row
BEGIN
    DECLARE message_content VARCHAR(255);
    DECLARE theme_id INT;

    -- 获取插入消息的内容和对应的theme_id
    SELECT NEW.content, NEW.topic_id INTO message_content, theme_id;

    -- 更新theme表中对应theme_id的summary字段
    UPDATE theme
    SET summary = SUBSTRING(message_content, 1, 30)
    WHERE id = theme_id;
END;

