create definer = test@`` trigger message_insert_trigger
    after insert
    on message
    for each row
BEGIN
    UPDATE theme
    SET update_time = NOW()
    WHERE id = NEW.topic_id;
END;

